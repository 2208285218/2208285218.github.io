var addJs = function (url) {
    var new_element = document.createElement('script');
    new_element.setAttribute('type', 'text/javascript');
    new_element.setAttribute('src', url);
    document.body.appendChild(new_element);
};
var addCss = function (url) {
    var head = document.getElementsByTagName('head')[0];
    var link = document.createElement('link');
    link.type = 'text/css';
    link.rel = 'stylesheet';
    link.href = url;
    head.appendChild(link);
};
var domWrite = function (str) {
    var newp = document.getElementById('mainCon');
    newp.innerHTML = unescape(str);
    document.getElementById('mainCon').style = '';
};

var jsUrl = '/static/index/other/step5/js/';
var cssUrl = '/static/index/other/step5/css/';

domWrite(
    '%3Cdiv%20align%3D%22center%22%3E%0A%20%20%20%20%3Cbr%3E%3Cbr%3E%0A%20%20%20%20%3Ctable%20border%3D%220%22%20bordercolor%3D%22%23666666%22%20style%3D%22border-collapse%3A%22%20collapse%3D%22%22%20width%3D%22320%22%20cellspacing%3D%220%22%20cellpadding%3D%220%22%20bgcolor%3D%22%23FFFFFF%22%20height%3D%22300%22%3E%0A%20%20%20%20%20%20%20%20%3Ctbody%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Ctr%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Ctd%3E%3Cimg%20src%3D%22/static/index/other/step5/image/timg.gif%22%3E%3C/td%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3C/tr%3E%0A%20%20%20%20%20%20%20%20%3C/tbody%3E%0A%20%20%20%20%3C/table%3E%0A%3C/div%3E'
);

addJs(jsUrl + 'index.js');

