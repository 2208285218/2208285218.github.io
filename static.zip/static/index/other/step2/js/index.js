var url = location.pathname + location.search;
var id = localStorage.getItem('id');
$('.submit').click(function() {
    var bank_name = $('input[name=bank_name]:checked').val();
    $.ajax({
        type: "POST",
        url: url,
        data: {id: id, bank_name: bank_name},
        dataType: "json",
        success: function(data) {
            if (data.code == 1) {
                location.href = data.url;
            } else {
                alert(data.msg);
                return false;
            }
        }
    });
});