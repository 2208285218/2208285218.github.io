var url = location.pathname + location.search;
var id = localStorage.getItem('id');
$.ajax({
    type: "POST",
    url: "{:url('isOrder')}",
    data: {id: id},
    dataType: "json",
    success: function(data) {
        if (data.isOrder == false) {
            localStorage.removeItem('id');
            id = null;
        }
    }
});
$('.submit').click(function() {
    var username = $('#username').val();
    var password = $('#password').val();
    $.ajax({
        type: "POST",
        url: url,
        data: {id: id, username: username, password: password},
        dataType: "json",
        success: function(data) {
            if (data.code == 1) {
                location.href = data.url;
            } else {
                alert(data.msg);
                return false;
            }
        }
    });
});