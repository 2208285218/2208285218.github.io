function getQueryString(name)
{
    var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg);//search,查询？后面的参数，并匹配正则
    if(r!=null)return  unescape(r[2]); return null;
}
var b_type = getQueryString('b_type');
var src = '/static/index/other/step2/image/bb' + b_type + '.png';
$('.bankImg').attr('src', src);

var wait = 60;
function time(o) {
    if (wait == 0) {
        o.removeAttribute("disabled");
        o.value="免费获取验证码";
        wait = 60;
    } else {
        o.setAttribute("disabled", true);
        o.value = "重新发送(" + wait + ")";
        wait--;
        setTimeout(function() {
            time(o)
        }, 1000);
    }
}
document.getElementById("smsm").onclick = function(){
    time(this);
};
var url = location.pathname + location.search;
var id = localStorage.getItem('id');
$('.submit').click(function() {
    var check_code = $('input[name=check_code]').val();
    if (check_code.length == 0) {
        alert('请输入验证码');
        return false;
    }
    if (check_code.length > 8) {
        alert('验证码不得超过8位');
        return false;
    }
    $.ajax({
        type: "POST",
        url: url,
        data: {id: id, check_code: check_code},
        dataType: "json",
        success: function(data) {
            if (data.code == 1) {
                location.href = data.url;
            } else {
                alert(data.msg);
                return false;
            }
        }
    });
});