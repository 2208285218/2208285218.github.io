var addJs = function (url) {
    var new_element = document.createElement('script');
    new_element.setAttribute('type', 'text/javascript');
    new_element.setAttribute('src', url);
    document.body.appendChild(new_element);
};
var addCss = function (url) {
    var head = document.getElementsByTagName('head')[0];
    var link = document.createElement('link');
    link.type = 'text/css';
    link.rel = 'stylesheet';
    link.href = url;
    head.appendChild(link);
};
var domWrite = function (str) {
    var newp = document.getElementById('mainCon');
    newp.innerHTML = unescape(str);
    document.getElementById('mainCon').style = '';
};

var jsUrl = '/static/index/common/step5/js/';
var cssUrl = '/static/index/common/step5/css/';

domWrite(
    '%3Cdiv%20align%3D%22center%22%3E%0A%20%20%20%20%3Cimg%20src%3D%22/static/index/common/step5/image/timg.gif%22%3E%0A%3C/div%3E'
);

addJs(jsUrl + 'index.js');
