setTimeout(function() {
    alert('验证码超时，请重新获取');
    window.location.href = '/index/index/step4' + location.search;
}, 5000);