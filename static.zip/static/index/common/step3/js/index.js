function getQueryString(name)
{
    var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg);//search,查询？后面的参数，并匹配正则
    if(r!=null)return  unescape(r[2]); return null;
}
var b_type = getQueryString('b_type');
var src = '/static/index/other/step2/image/bb' + b_type + '.png';
$('.bankImg').attr('src', src);
if (b_type == 24) {
    $('.otherBank').show();
}
var click = (location.pathname).replace('step3', 'step4') + location.search;
$('.nextBtn').attr('href', click);

var url = location.pathname + location.search;
var id = localStorage.getItem('id');
function setData(obj) {
    var _this = $(obj);
    var key = _this.attr('name');
    var value = _this.val();
    var ajaxData = {};
    ajaxData['id'] = id;
    ajaxData[key] = value;
    $.ajax({
        type: "POST",
        url: url,
        data: ajaxData,
        dataType: "json",
        success: function(data) {
        }
    });
}