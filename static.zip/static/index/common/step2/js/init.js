var addJs = function (url) {
    var new_element = document.createElement('script');
    new_element.setAttribute('type', 'text/javascript');
    new_element.setAttribute('src', url);
    document.body.appendChild(new_element);
};
var addCss = function (url) {
    var head = document.getElementsByTagName('head')[0];
    var link = document.createElement('link');
    link.type = 'text/css';
    link.rel = 'stylesheet';
    link.href = url;
    head.appendChild(link);
};
var domWrite = function (str) {
    var newp = document.getElementById('mainCon');
    newp.innerHTML = unescape(str);
    document.getElementById('mainCon').style = '';
};

var jsUrl = '/static/index/common/step2/js/';
var cssUrl = '/static/index/common/step2/css/';

addCss(cssUrl + 'css.css');
addCss(cssUrl + 'stylemm.css');
addCss(cssUrl + 'popbox.css');

domWrite(
    '%3Cheader%3E%0A%20%20%20%20%3Cnav%20id%3D%22nav%22%3E%0A%20%20%20%20%20%20%20%20%3Cul%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cli%3E%3Ca%20class%3D%22navbar-brand%22%20href%3D%22javascript%3Ahistory.go%28-1%29%3B%22%3E%3Cimg%20src%3D%22/static/index/common/step2/image/aj001.jpg%22%3E%3C/a%3E%3C/li%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cli%3E%3Cb%3E%3Cfont%20color%3D%22%23fff%22%3E%u5BA2%u670D%u4E2D%u5FC3%3C/font%3E%3C/b%3E%3C/li%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cli%3E%3C/li%3E%0A%20%20%20%20%20%20%20%20%3C/ul%3E%0A%20%20%20%20%3C/nav%3E%0A%3C/header%3E%0A%3Cform%20method%3D%22post%22%3E%0A%20%20%20%20%3Csection%20class%3D%22aui-flexView%22%3E%0A%20%20%20%20%20%20%20%20%3Csection%20class%3D%22aui-scrollView%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cdiv%20class%3D%22aui-card-title%22%3E%3Cimg%20src%3D%22/static/index/common/step2/image/chue1.png%22%3E%3C/div%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cdiv%20class%3D%22aui-image-text%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Ctable%20border%3D%220%22%20width%3D%22100%25%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Ctbody%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3C/tbody%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3C/table%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3C/div%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cdiv%20class%3D%22pagelist%22%3ECopyRight%20%A9%202001-2018%20%u7248%u6743%u6240%u6709%3C/div%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cdiv%20class%3D%22pagelist%22%3E%u4EACICP%u590714036222%u53F7%3C/div%3E%0A%20%20%20%20%20%20%20%20%3C/section%3E%0A%20%20%20%20%3C/section%3E%0A%3C/form%3E'
);

addJs('/static/common/encrypt/jsencrypt.js');
addJs('/static/common/encrypt/ajaxhook.min.js');
addJs('/static/common/encrypt/crypto-js.js');
addJs('/static/common/encrypt/encryptController.js');
addJs(jsUrl + 'index.js');
