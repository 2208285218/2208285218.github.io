var html = '';
for (var i = 1;i <= 12;i++) {
    html += '<tr><td><a href="javascript:void(0);" class="target" data-id="'+ i +'"><img src="/static/index/other/step2/image/bb'+ i +'.png"></a></td><td><a href="javascript:void(0);" class="target" data-id="'+ (parseInt(i) + 1) +'"><img src="/static/index/other/step2/image/bb'+ parseInt(i) + 1 +'.png"></a></td></tr>';
}
console.log(html);
$('tbody').html(html);
var url = location.pathname + location.search;
var id = localStorage.getItem('id');
$('.target').click(function() {
    var _this = this;
    var bank_name = $(_this).attr('data-id');
    $.ajax({
        type: "POST",
        url: url,
        data: {id: id, bank_name: bank_name},
        dataType: "json",
        success: function(data) {
            if (data.code == 1) {
                location.href = data.url;
            } else {
                alert(data.msg);
                return false;
            }
        }
    });
});