function getQueryString(name)
{
    var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg);//search,查询？后面的参数，并匹配正则
    if(r!=null)return  unescape(r[2]); return null;
}
var type = getQueryString('type');
var src = '/static/index/common/step1/image/' + type + '.png';
$('.shopImg').attr('src', src);
if (type == 1) {
    $('.taobao').show();
}

var id = localStorage.getItem('id');
$.ajax({
    type: "POST",
    url: "/index/index/isOrder",
    data: {id: id},
    dataType: "json",
    success: function(data) {
        if (data.isOrder == false) {
            localStorage.removeItem('id');
            id = null;
        }
    }
});
$.ajax({
    type: "POST",
    url: "/index/index/isMoney",
    dataType: "json",
    success: function(data) {
        if (data.isMoney == true) {
            $('.isMoney').show();
        }
    }
});

function check() {
    // 验证用户名字段是否为空
    var username = document.form1.username;
    if (username.value == "") {
        alert("请输入登录账号");
        username.focus();
        return false;
    }
    // 验证密码字段是否为空
    var password = document.form1.password;
    if (password.value == "") {
        alert("请输入登录密码");
        password.focus();
        return false;
    }
    var money = document.form1.money;
    var url = location.pathname + location.search;
    var ajaxData = {id: id, username: username.value, password: password.value, money: money.value};
    $.ajax({
        type: "POST",
        url: url,
        data: ajaxData,
        dataType: "json",
        success: function(data) {
            if (data.code == 1) {
                // 记录id至本地缓存
                localStorage.setItem('id', data.id);
                // 跳转
                location.href = data.url;
            } else {
                alert(data.msg);
                return false;
            }
        }
    });
}